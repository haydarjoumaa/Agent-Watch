# Phase 6 — Notifications and Navigation

**Goal:** Notify on actionable agent requests through VS Code and native OS notifications.

## Suggested files
```text
apps/vscode-extension/src/notifications/VscodeNotifier.ts
apps/local-daemon/src/notifications/DesktopNotifier.ts
apps/local-daemon/src/notifications/NotificationPolicy.ts
apps/vscode-extension/src/commands/goToAgent.ts
```

## Steps
1. Notify on confirmed `waiting_approval` and `waiting_input`; optionally `failed` and `completed`.
2. Use `vscode.window.showInformationMessage` for in-editor alerts.
3. Choose and test a platform-appropriate native notification implementation on macOS, Linux, and Windows; VS Code message APIs alone do not guarantee desktop notifications.
4. Persist acknowledgement/deduplication state so reconnects do not re-alert.
5. Offer `Open project` / `View agent` actions. Remote-device alerts should show the source device and cannot automatically focus a window on another computer.
6. Implement quiet hours, per-agent preferences, and notification privacy (no prompt or code excerpts by default).

## Acceptance
- A single pending approval produces at most one desktop alert per chosen target device.
- Repeated state snapshots don't create repeated alerts.
- Local project navigation works where supported; remote projects are labeled remote.
- No notification silently approves or rejects agent actions.

## Next phase
Proceed only after the acceptance criteria are met.
