# Phase 7 — Docker and VPS Deployment

**Goal:** Deploy the central service securely on a cloud VPS.

## Suggested files
```text
apps/server/Dockerfile
docker-compose.yml
.env.example
infra/Caddyfile
infra/backup.md
infra/deploy.md
```

## Steps
1. Provision a VPS, DNS name, non-root deploy user, SSH key authentication, and firewall.
2. Build a multi-stage Docker image for the Node.js server.
3. Configure HTTPS/WSS reverse proxy (e.g. Caddy) and certificate renewal.
4. Keep MongoDB private: managed database with restricted access or internal Docker network; never expose MongoDB publicly.
5. Inject secrets through secure deployment configuration, not source control.
6. Add health checks, restart policies, resource limits, log rotation, backup and restore procedure.
7. Verify TLS, WebSocket upgrades, device revocation, and reconnect behavior from two networks.

## Acceptance
- Service is reachable via HTTPS/WSS with valid TLS.
- Unauthorized clients cannot read or submit events.
- Server restart preserves durable event history and clients reconnect.
- Database and administrative ports are not exposed to the public internet.

## Next phase
Proceed only after the acceptance criteria are met.
