# Agent Watcher — Development Roadmap

A multi-agent attention monitor for VS Code, with local multi-window aggregation and cloud synchronization across devices.

## Phases
1. [Agent Detection](01-agent-detection.md)
2. [VS Code Extension](02-vscode-extension.md)
3. [Local Multi-Window Monitoring](03-local-multi-window.md)
4. [Backend API and Database](04-backend-database.md)
5. [Real-Time Multi-Device Synchronization](05-websocket-sync.md)
6. [Notifications and Navigation](06-notifications.md)
7. [Docker and VPS Deployment](07-docker-vps.md)
8. [Testing and Release](08-testing-release.md)

## Guiding principles
- **Prove event detection first.** Codex CLI, Codex VS Code, Claude Code, and Copilot may expose different integration surfaces. Confirm against current official docs and installed versions.
- **Never automatically approve actions.** The first release only observes and notifies.
- **Privacy by default.** Send minimal event metadata, not source code or prompts.
- **Local-first, cloud-ready.** Phases 1–3 work without a VPS; Phases 4–7 add secure remote synchronization.
- **Keep evidence explicit.** Distinguish confirmed hooks from inferred status.

## Suggested monorepo layout
```text
agent-watcher/
  apps/
    agent-bridge/
    vscode-extension/
    local-daemon/
    server/
  packages/
    shared/
  infra/
  docs/
```

## Suggested stack
TypeScript, VS Code Extension API, Node.js/Express, WebSocket (`ws`), MongoDB, Docker, HTTPS/WSS, Vitest.
