# Phase 1 — Agent Detection

**Goal:** Verify supported Codex, Claude Code, and Copilot integration mechanisms; detect actual human-attention states.

## Scope
- Research current, version-specific hook/event support for **Codex CLI**, **Codex VS Code extension**, **Claude Code**, and **GitHub Copilot in VS Code** separately.
- Do **not** assume a CLI hook works inside the VS Code extension.
- Create adapters that emit normalized events and label their evidence (`confirmed` vs `inferred`).
- Prioritize `waiting_approval` and `waiting_input`; support `working`, `completed`, and `failed` where available.

## Suggested files
```text
packages/shared/src/events.ts
apps/agent-bridge/src/adapters/codex.ts
apps/agent-bridge/src/adapters/claude.ts
apps/agent-bridge/src/adapters/copilot.ts
apps/agent-bridge/src/normalize.ts
apps/agent-bridge/src/cli.ts
apps/agent-bridge/test/normalize.test.ts
```

## Event contract
```ts
export type AgentKind = 'codex' | 'claude' | 'copilot';
export type AgentState = 'working' | 'waiting_approval' | 'waiting_input' | 'completed' | 'failed';
export interface AgentEvent {
  eventId: string;
  deviceId: string;
  windowId?: string;
  agent: AgentKind;
  sessionId: string;
  state: AgentState;
  observedAt: string;
  confidence: 'confirmed' | 'inferred';
  projectLabel?: string;
}
```

## Steps
1. Install a supported Codex version and inspect its current official hook documentation and installed config options.
2. Register a non-mutating listener using the **verified** configuration format; record the exact version and configuration in `docs/compatibility.md`.
3. Trigger a harmless approval in a disposable project; verify that the listener runs **before** approval and doesn't change the approval decision.
4. Repeat inside the Codex VS Code extension. If unsupported, mark it unsupported and investigate approved alternatives instead of scraping private internals.
5. Add Claude Code and Copilot integrations only after independently verifying their event mechanisms.
6. Validate incoming event JSON and avoid logging source code, prompt text, credentials, or command arguments by default.

## Tests and acceptance
- A genuine approval produces exactly one normalized `waiting_approval` event with session identity.
- Ordinary tool execution does not produce a false approval alert.
- Unsupported integrations fail clearly and do not claim confirmed detection.
- Adapter errors never approve, reject, or block agent actions unexpectedly.

## Dependencies
Node.js, TypeScript, `tsx`, `zod`, test runner (Vitest). **No VPS required.**

## Next phase
Proceed only after the acceptance criteria are met.
