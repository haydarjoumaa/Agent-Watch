# Phase 4 — Backend API and Database

**Goal:** Implement authenticated event ingestion and persistent multi-device state.

## Suggested files
```text
apps/server/src/app.ts
apps/server/src/config/env.ts
apps/server/src/db/connect.ts
apps/server/src/models/User.ts
apps/server/src/models/Device.ts
apps/server/src/models/AgentEvent.ts
apps/server/src/routes/devices.ts
apps/server/src/routes/events.ts
apps/server/src/middleware/auth.ts
apps/server/src/middleware/error.ts
```

## API draft
```text
POST /api/devices/register
POST /api/events
GET  /api/events?cursor=...
GET  /api/devices
POST /api/devices/:id/revoke
GET  /healthz
```

## Steps
1. Create Express + TypeScript app, request validation, centralized errors, and environment validation.
2. Model users, devices, agent sessions, and append-only events in MongoDB; add TTL/retention policy.
3. Require authenticated user ownership for all reads and writes.
4. Implement device enrollment and revocable device credentials (store only hashed secrets where appropriate).
5. Use server-side authorization, rate limiting, size limits, and idempotent event ingestion keyed by `(deviceId, eventId)`.
6. Store minimal metadata only; avoid raw prompts, command arguments, and source files.
7. Add pagination, indexes, and tests for cross-user isolation.

## Acceptance
- Authenticated device can submit an event and owner can read it.
- Device A cannot access user B's events.
- Duplicate event submission doesn't create duplicate records.
- Revoked device cannot publish new events.

## Next phase
Proceed only after the acceptance criteria are met.
