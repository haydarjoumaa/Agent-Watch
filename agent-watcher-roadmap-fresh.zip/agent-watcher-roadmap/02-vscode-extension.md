# Phase 2 — VS Code Extension

**Goal:** Create a local VS Code dashboard that displays normalized events and allows navigation to a relevant local workspace.

## Suggested files
```text
apps/vscode-extension/package.json
apps/vscode-extension/tsconfig.json
apps/vscode-extension/src/extension.ts
apps/vscode-extension/src/tree/AgentTreeProvider.ts
apps/vscode-extension/src/status/StatusBar.ts
apps/vscode-extension/src/commands/openWorkspace.ts
apps/vscode-extension/src/client/LocalEventClient.ts
```

## Implementation
1. Scaffold a TypeScript VS Code extension with activation events and command contributions.
2. Add a TreeView with agent → session → latest state hierarchy.
3. Add a status bar count for **confirmed** pending requests.
4. Connect to a local event source (mock events first; Phase 1 adapter second).
5. Register commands to open/focus a local workspace using documented VS Code APIs. Do not promise exact window focusing until verified per OS.
6. Clean up subscriptions and listeners in `deactivate()`.

## Minimal extension sketch
```ts
import * as vscode from 'vscode';
export function activate(context: vscode.ExtensionContext) {
  const status = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left);
  status.text = '$(bell) Agents: 0 waiting';
  status.show();
  context.subscriptions.push(status);
}
```

## Acceptance
- Sidebar updates when mock or confirmed adapter events arrive.
- Status bar counts unresolved approval/input events correctly.
- Extension activation/deactivation doesn't leak listeners.
- UI distinguishes disconnected and unsupported agents from idle agents.

## Next phase
Proceed only after the acceptance criteria are met.
