# Phase 3 — Local Multi-Window Monitoring

**Goal:** Aggregate events from multiple VS Code windows on one computer.

## Suggested files
```text
apps/local-daemon/src/index.ts
apps/local-daemon/src/ipc/server.ts
apps/local-daemon/src/state/AgentRegistry.ts
apps/local-daemon/src/state/dedupe.ts
apps/local-daemon/src/windows/WindowRegistry.ts
apps/vscode-extension/src/client/LocalEventClient.ts
```

## Architecture
Each VS Code extension host publishes events to a **single per-user local daemon**. All extension windows subscribe to its state snapshot and incremental updates.

## Steps
1. Use a Unix-domain socket on macOS/Linux or a named pipe on Windows; protect it with OS user permissions.
2. Assign stable device IDs and ephemeral window IDs; session IDs belong to the agent, not the VS Code window.
3. Establish a single-daemon startup/lock strategy and recover after crashes.
4. Store active sessions in memory; optionally persist minimal state for restart recovery.
5. Deduplicate by stable event ID and transition state; handle out-of-order updates.
6. Implement stale-session timeout and reconnect snapshots.
7. Support navigating to the appropriate workspace; exact OS window focus is best-effort.

## Acceptance
- Three open VS Code windows show the same aggregate state.
- Closing one window does not terminate the monitor for other windows.
- Reconnect restores state without duplicate alerts.
- Local IPC cannot be accessed by unrelated local users under normal permissions.

## Next phase
Proceed only after the acceptance criteria are met.
