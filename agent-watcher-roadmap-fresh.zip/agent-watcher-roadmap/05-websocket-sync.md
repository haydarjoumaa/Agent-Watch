# Phase 5 — Real-Time Multi-Device Synchronization

**Goal:** Synchronize events and active states between authenticated clients.

## Suggested files
```text
apps/server/src/realtime/wsServer.ts
apps/server/src/realtime/authenticate.ts
apps/server/src/realtime/subscriptions.ts
apps/server/src/realtime/broadcast.ts
apps/local-daemon/src/cloud/CloudSyncClient.ts
packages/shared/src/protocol.ts
```

## Protocol draft
```ts
type ServerMessage =
  | { type: 'event'; event: AgentEvent }
  | { type: 'snapshot'; events: AgentEvent[]; cursor: string }
  | { type: 'heartbeat'; at: string };
```

## Steps
1. Serve WSS behind HTTPS; authenticate connections before subscribing them to a user's channel.
2. Use short-lived credentials or one-time connection tickets; do not place long-lived secrets in URL logs.
3. Authorize every event's device/user identity on the server.
4. Broadcast events only to devices owned by the same user.
5. Add ping/pong, exponential backoff with jitter, and clean disconnect handling.
6. On reconnect, fetch a snapshot or cursor-based missed events; define ordering semantics.
7. Ensure duplicate deliveries are harmless; test offline/online transitions.

## Acceptance
- An approval on computer A appears on computer B within seconds under normal connectivity.
- Offline computer catches up after reconnect.
- User B never receives user A's events.
- Heartbeats detect disconnected devices; reconnect does not spam notifications.

## Next phase
Proceed only after the acceptance criteria are met.
