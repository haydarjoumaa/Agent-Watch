# Phase 8 — Testing and Release

**Goal:** Make the extension and server reliable and publishable.

## Suggested files
```text
apps/vscode-extension/test/extension.test.ts
apps/server/test/auth.test.ts
apps/server/test/events.test.ts
apps/server/test/websocket.test.ts
apps/local-daemon/test/ipc.test.ts
docs/compatibility.md
docs/privacy.md
docs/troubleshooting.md
.github/workflows/ci.yml
```

## Test matrix
- Agent integration: Codex CLI, Codex VS Code, Claude Code, Copilot (record exact versions and confirmed support).
- Operating systems: macOS, Linux, Windows (where available).
- Multi-window: one, two, and five windows.
- Connectivity: online, offline, reconnect, VPS restart, token expiry/revocation.
- Security: cross-user access, spoofed device, malformed JSON, oversized payload, secret leakage.
- Notifications: duplicates, resolved requests, quiet hours, unsupported native-notification platforms.

## Steps
1. Add unit tests for event normalization, state transitions, and deduplication.
2. Add integration tests for REST, WebSocket, IPC, and device authorization.
3. Test actual approval events on supported agent versions; document unsupported combinations.
4. Add CI lint/typecheck/test/package steps.
5. Package VS Code extension (`vsce` or current supported packaging tool); verify extension permissions and README.
6. Decide on private distribution vs marketplace publishing; add privacy policy and operational docs.

## Acceptance
- CI passes; core auth, event, and notification flows have automated coverage.
- No unsupported agent is advertised as reliable.
- New install instructions work on a clean machine.
- Recovery from daemon/server restart is tested.

## Next phase
Proceed only after the acceptance criteria are met.
